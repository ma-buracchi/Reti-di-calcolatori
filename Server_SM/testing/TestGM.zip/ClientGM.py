from socket import *

with open('TestGM', 'r') as f:
    string = f.readline()
    lines = string.split(',')
    i = 0
    while i < len(lines):
        request = lines[i] + '\r\n'
        client = socket(AF_INET, SOCK_STREAM)
        client.connect(('localhost', 8080))
        client.sendall(request)
        response = client.recv(50)
        client.close()
        i += 1
        print response
